from django.shortcuts import render
from .models import Menu,Review
from.serializer import MenuModelSer,UserSerializer,ReviewModelser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import viewsets
from rest_framework import authentication
from rest_framework import permissions
from rest_framework .decorators import action


# Create your views here.
# ----normal serializer----
# class DishList(APIView):
    # def get(self,request,*args,**kwargs):
    #     dish=Menu.objects.all()
    #     dish_ser=MenuSerializer(dish,many=True)
    #     return Response(data=dish_ser.data)
    # def post(self,request,*args,**kwargs):
    #     ser=MenuSerializer(data=request.data)
    #     if ser.is_valid():
    #         dish=ser.validated_data.get("dish")
    #         price=ser.validated_data.get("price")
    #         rating=ser.validated_data.get("rating")
    #         category=ser.validated_data.get("category")
    #         Menu.objects.create(dish=dish,price=price,rating=rating,category=category)
    #         return Response({"msg":"OK"})
    #     return Response({"msg":"FAILED"})
# class SpecificDish(APIView):
    # def get(self,request,*args,**kwargs):
    #     id=kwargs.get("did")
    #     item=Menu.objects.get(id=id)
    #     ser=MenuSerializer(item)
    #     return Response(data=ser.data)
    # def delete(self,request,*args,**kwargs):
    #     id=kwargs.get("did")
    #     item=Menu.objects.get(id=id)
    #     item.delete()
    #     return Response({"msg":"OK"})
    # def put(self,request,*args,**kwargs):
    #     id=kwargs.get("did")
    #     item=Menu.objects.get(id=id)
    #     ser=MenuSerializer(data=request.data)
    #     if ser.is_valid():
    #          dish=ser.validated_data.get("dish")
    #          price=ser.validated_data.get("price")
    #          rating=ser.validated_data.get("rating")
    #          category=ser.validated_data.get("category")   
    #          item.dish=dish
    #          item.price=price
    #          item.rating=rating
    #          item.category=category
    #          item.save()
    #          return Response({"msg":"OK"})
    #     return Response({"msg":"FAILED"}) 

# ----static dataset-----    
# class DishList(APIView):
#     def get(self,request,*args,**kwargs):
#         allitems=menu_items
#         if 'category' in request.query_params:
#            # print(request.query_params)
#             cat=request.query_params.get("category")
#             dishes=[i for i in allitems if i['category']==cat]
#             return Response(data=dishes)
#         if 'limit' in request.query_params:
#             lmt=int(request.query_params.get("limit"))
#             allitems=allitems[0:lmt]
#         return Response(data=allitems)
    
#     def post(self,request,*args,**kwargs):
#         data=request.data
#         menu_items.append(data)
#         return Response(data=menu_items)

# class SpecificDish(APIView):
#     def get(self,request,*args,**kwargs):
#         did=kwargs.get("did")
#         dish=[i for i in menu_items if i['id']==did].pop()
#         return Response(data=dish)
#     def delete(self,request,*args,**kwargs):
#         did=kwargs.get("did")
#         dish=[i for i in menu_items if i['id']==did].pop()
#         menu_items.remove(dish)
#         return Response(data=menu_items)
#     def put(self,request,*args,**kwargs):
#         did=kwargs.get("did")
#         data=request.data
#         dish=[i for i in menu_items if i['id']==did].pop()
#         dish.update(data)
#         return Response(data=dish)

# ----using modelserializer----

class DishMList(APIView):
    def get(self,request,*args,**kwargs):
        menu=Menu.objects.all()
        ser=MenuModelSer(menu,many=True)
        return Response(data=ser.data)
    def post(self,request,*args,**kwargs):
       ser=MenuModelSer(data=request.data)
       if ser.is_valid():
           ser.save()
           return Response({"msg":"OK"})
       else:
          return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)
class SpecificMDish(APIView):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("mid")
        item=Menu.objects.get(id=id)
        ser=MenuModelSer(item)
        return Response(data=ser.data)
    def delete(self,request,*args,**kwargs):
        id=kwargs.get("mid")
        item=Menu.objects.get(id=id)
        item.delete()
        return Response({"msg":"OK"})

    def put(self,request,*args,**kwargs):
        id=kwargs.get("mid")
        item=Menu.objects.get(id=id)
        ser=MenuModelSer(data=request.data,instance=item)
        if ser.is_valid():
          ser.save()
          return Response({"msg":"OK"})
        else:
            return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)

class UserView(APIView):
    def post(self,request,*args,**kwargs):
        ser=UserSerializer(data=request.data)
        if ser.is_valid():
            ser.save()
            return Response({"msg":"ok"})
        else:
            return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)
        
#------views using viewset----
class MenuView(viewsets.ViewSet):
    def list(self,request,*args,**kwargs):
        if 'category'in request.query_params:
            allitems=allitems.filter(category=request.query_params.get("category"))
        if 'pricelt'in request.query_params:
            allitems=allitems.filter(category=request.query_params.get("pricelt"))
            ser=MenuModelSer(allitems,many=True)
            return Response(data=ser.data)
        menu=Menu.objects.all()
        ser=MenuModelSer(menu,many=True)
        return Response(data=ser.data)
    def retrieve(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        item=Menu.objects.get(id=id)
        ser=MenuModelSer(item)
        return Response(data=ser.data)
    def create(self,request,*args,**kwargs):
        ser=MenuModelSer(data=request.data)
        if ser.is_valid():
            ser.save()
            return Response({"msg":"added"})
        else:
            return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)
    def update(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        item=Menu.objects.get(id=id)
        ser=MenuModelSer(data=request.data,instance=item)
        if ser.is_valid():
            ser.save()
            return Response({"msg":"update"})
        else:
            return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)
    def destroy(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        item=Menu.objects.get(id=id)
        item.delete()
        return Response({"msg":"Deleted"})
    
#---------views using model viewsets----
class MenuModelView(viewsets.ModelViewSet):
    model=Menu
    serializer_class=MenuModelSer
    queryset=Menu.objects.all()
    # authentication_classes=[authentication.TokenAuthentication]
    permission_classes=[permissions.IsAuthenticated]

class MenuModelView(viewsets.ModelViewSet):
    model=Menu
    serializer_class=MenuModelSer
    queryset=Menu.objects.all()
    # authentication_classes=[authentication.TokenAuthentication]
    # permission_classes=[permissions.IsAuthenticated]
    @action(detail=True,methods=['get'])
    def get_reviews(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        dish=Menu.objects.get(id=id)
        rev=Review.objects.filter(dish=dish)
        ser=ReviewModelser(rev,many=True)
        return Response(data=ser.data)
    @action(detail=True,methods=['post'])
    def add_reviews(self,request,*args,**kwargs):
        id=kwargs.get("pk")
        dish=Menu.objects.get(id=id)
        user=request.user
        print("addreview",user,dish)
        ser=ReviewModelser(data=request.data,context={"user":user,"dish":dish})
        if ser.is_valid():
            ser.save()
            return Response({"msg":"Review added"})
        else:
            return Response({"msg":ser.errors},status=status.HTTP_404_NOT_FOUND)




    